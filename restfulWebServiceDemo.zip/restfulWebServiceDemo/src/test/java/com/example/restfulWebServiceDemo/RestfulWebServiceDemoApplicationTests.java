package com.example.restfulWebServiceDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
