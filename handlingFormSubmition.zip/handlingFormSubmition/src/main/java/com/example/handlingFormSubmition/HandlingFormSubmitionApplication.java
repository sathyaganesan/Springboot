package com.example.handlingFormSubmition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandlingFormSubmitionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandlingFormSubmitionApplication.class, args);
	}

}
